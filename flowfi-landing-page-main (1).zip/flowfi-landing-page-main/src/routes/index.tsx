import { createFileRoute } from "@tanstack/react-router";
import { Nav } from "@/components/flowfi/Nav";
import { Hero } from "@/components/flowfi/Hero";
import { Problems } from "@/components/flowfi/Problems";
import { Features } from "@/components/flowfi/Features";
import { FlowAI } from "@/components/flowfi/FlowAI";
import { Bento } from "@/components/flowfi/Bento";
import { TestAppCTA } from "@/components/flowfi/TestAppCTA";
import { Testimonials } from "@/components/flowfi/Testimonials";
import { Roadmap } from "@/components/flowfi/Roadmap";
import { Waitlist } from "@/components/flowfi/Waitlist";
import { Footer } from "@/components/flowfi/Footer";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  return (
    <main className="relative min-h-screen overflow-x-hidden noise">
      <Nav />
      <Hero />
      <Problems />
      <Features />
      <FlowAI />
      <TestAppCTA />
      <Bento />
      <Testimonials />
      <Roadmap />
      <Waitlist id="waitlist" />
      <Footer />
    </main>
  );
}
