import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Menu, X } from "lucide-react";
import { Logo } from "./Logo";
import { BetaBadge } from "./BetaBadge";

const links = [
  { label: "The problem", href: "#problems" },
  { label: "Features", href: "#features" },
  { label: "Flow AI", href: "#ai" },
  { label: "Roadmap", href: "#roadmap" },
  { label: "Reactions", href: "#reviews" },
];

export function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header className="fixed inset-x-0 top-0 z-50 px-4 pt-3 sm:pt-4">
      <div
        className={`mx-auto flex max-w-6xl items-center justify-between rounded-2xl px-4 py-2.5 transition-all duration-300 ${
          scrolled ? "glass-strong shadow-[0_8px_32px_-12px_rgba(0,0,0,0.5)]" : "border border-transparent"
        }`}
      >
        <div className="flex items-center gap-2.5">
          <Logo />
          <BetaBadge label="Beta" />
        </div>
        <nav className="hidden items-center gap-6 md:flex">
          {links.map((l) => (
            <a key={l.href} href={l.href} className="text-sm text-muted-foreground transition-colors hover:text-foreground">
              {l.label}
            </a>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <a href="#waitlist" className="hidden rounded-full bg-foreground px-4 py-2 text-sm font-medium text-background transition-transform hover:scale-[1.03] sm:inline-block">
            Join Waitlist
          </a>
          <button
            aria-label="Open menu"
            className="md:hidden rounded-full glass p-2"
            onClick={() => setOpen((o) => !o)}
          >
            {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className="mx-auto mt-2 max-w-6xl glass-strong rounded-2xl p-4 md:hidden"
          >
            <div className="flex flex-col gap-1">
              {links.map((l) => (
                <a key={l.href} href={l.href} onClick={() => setOpen(false)} className="rounded-xl px-3 py-2.5 text-sm hover:bg-white/5">
                  {l.label}
                </a>
              ))}
              <a href="#waitlist" onClick={() => setOpen(false)} className="mt-2 rounded-xl bg-foreground px-3 py-2.5 text-center text-sm font-medium text-background">
                Join Waitlist
              </a>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
