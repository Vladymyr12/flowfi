import { Github, Twitter, Instagram } from "lucide-react";
import { Logo } from "./Logo";
import { BetaBadge } from "./BetaBadge";

export function Footer() {
  return (
    <footer className="relative border-t border-white/5 py-12">
      <div className="mx-auto max-w-6xl px-4">
        <div className="grid gap-8 md:grid-cols-4">
          <div className="md:col-span-2">
            <div className="flex items-center gap-2.5">
              <Logo />
              <BetaBadge label="Beta" />
            </div>
            <p className="mt-3 max-w-xs text-sm text-muted-foreground">
              An AI-powered money app for the next generation. Currently in beta — join the waitlist to be first in.
            </p>
            <a
              href="#waitlist"
              className="mt-5 inline-flex items-center gap-2 rounded-full bg-[var(--gradient-primary)] px-4 py-2 text-sm font-semibold text-background hover:scale-[1.03] transition-transform"
            >
              Get early access
            </a>
          </div>

          <FooterCol title="Product" links={["Features", "Flow AI", "Test app", "Roadmap"]} />
          <FooterCol title="Company" links={["About", "Build log", "Contact", "Privacy", "Terms"]} />
        </div>

        <div className="mt-10 flex flex-col items-start justify-between gap-4 border-t border-white/5 pt-6 sm:flex-row sm:items-center">
          <p className="text-xs text-muted-foreground">© 2026 FlowFi Labs · Version Beta · Built in public.</p>
          <div className="flex items-center gap-3">
            {[Twitter, Instagram, Github].map((Icon, i) => (
              <a key={i} href="#" className="rounded-full glass p-2 hover:bg-white/[0.08]">
                <Icon className="h-4 w-4" />
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}

function FooterCol({ title, links }: { title: string; links: string[] }) {
  return (
    <div>
      <p className="text-sm font-semibold">{title}</p>
      <ul className="mt-3 space-y-2">
        {links.map((l) => (
          <li key={l}>
            <a href="#" className="text-sm text-muted-foreground hover:text-foreground">{l}</a>
          </li>
        ))}
      </ul>
    </div>
  );
}
