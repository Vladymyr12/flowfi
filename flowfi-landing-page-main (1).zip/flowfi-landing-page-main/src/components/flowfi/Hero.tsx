import { useState } from "react";
import { motion } from "motion/react";
import { ArrowRight, Apple, Play, Sparkles, TrendingUp, Target, PlayCircle } from "lucide-react";
import { PhoneMockup } from "./PhoneMockup";
import { BetaBadge } from "./BetaBadge";
import { DemoModal } from "./DemoModal";

export function Hero() {
  const [demoOpen, setDemoOpen] = useState(false);

  return (
    <section className="relative overflow-hidden pt-28 pb-20 sm:pt-36 sm:pb-28">
      {/* aurora */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="absolute inset-0 bg-[var(--gradient-aurora)] animate-aurora" />
        <div className="absolute inset-0 grid-bg opacity-40 [mask-image:radial-gradient(ellipse_at_top,black,transparent_70%)]" />
      </div>

      <div className="mx-auto max-w-6xl px-4">
        <div className="grid gap-12 md:grid-cols-2 md:items-center">
          <div>
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="inline-flex items-center gap-2"
            >
              <BetaBadge label="Version Beta · In Development" />
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.05 }}
              className="mt-5 text-balance font-display text-5xl font-semibold leading-[1.02] tracking-tight sm:text-6xl md:text-7xl"
            >
              Money built for the <span className="text-gradient">next generation.</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.12 }}
              className="mt-5 max-w-xl text-base text-muted-foreground sm:text-lg"
            >
              FlowFi is a Gen Z money app currently in beta. Track every dollar, crush savings goals, and let Flow AI coach you to financial calm. Join the waitlist for early access.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.7, delay: 0.18 }}
              className="mt-8 flex flex-wrap items-center gap-3"
            >
              <a
                href="#waitlist"
                className="group inline-flex items-center gap-2 rounded-full bg-[var(--gradient-primary)] px-5 py-3 text-sm font-semibold text-background transition-all hover:scale-[1.03] glow-mint"
              >
                Join the Waitlist
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" />
              </a>
              <button
                onClick={() => setDemoOpen(true)}
                className="inline-flex items-center gap-2 rounded-full glass px-5 py-3 text-sm font-medium hover:bg-white/[0.08]"
              >
                <PlayCircle className="h-4 w-4" /> See the test app
              </button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
              className="mt-8 flex flex-wrap items-center gap-3 text-xs text-muted-foreground"
            >
              <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5">
                <Apple className="h-3.5 w-3.5" /> Coming soon on iOS
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5">
                <Play className="h-3.5 w-3.5" /> Coming soon on Android
              </span>
            </motion.div>
          </div>

          <div className="relative">
            {/* Beta sticker on mockup */}
            <div className="absolute -top-2 right-2 z-10 sm:right-0">
              <motion.div
                initial={{ rotate: -8, opacity: 0, scale: 0.8 }}
                animate={{ rotate: -8, opacity: 1, scale: 1 }}
                transition={{ delay: 0.5, type: "spring" }}
                className="rounded-2xl bg-[var(--gradient-violet)] px-3 py-1.5 text-[10px] font-bold uppercase tracking-[0.18em] text-white shadow-[var(--shadow-violet)]"
              >
                App Preview · Beta
              </motion.div>
            </div>

            <PhoneMockup />

            {/* Floating cards */}
            <FloatingCard
              className="absolute -left-2 top-10 sm:-left-10"
              delay={0.6}
              animation="animate-float-y"
            >
              <div className="flex items-center gap-2">
                <div className="rounded-lg bg-mint/20 p-1.5">
                  <TrendingUp className="h-3.5 w-3.5 text-mint" />
                </div>
                <div>
                  <p className="text-[10px] text-muted-foreground">Concept · Weekly save</p>
                  <p className="font-display text-sm font-semibold">+$184.20</p>
                </div>
              </div>
            </FloatingCard>

            <FloatingCard
              className="absolute -right-2 top-32 sm:-right-8"
              delay={0.8}
              animation="animate-float-y-slow"
            >
              <div className="flex items-center gap-2">
                <div className="rounded-lg bg-violet/20 p-1.5">
                  <Sparkles className="h-3.5 w-3.5 text-violet" />
                </div>
                <div>
                  <p className="text-[10px] text-muted-foreground">Flow AI · preview</p>
                  <p className="text-[11px] font-medium leading-snug">Cancel 2 unused subs · Save $24/mo</p>
                </div>
              </div>
            </FloatingCard>

            <FloatingCard
              className="absolute -bottom-2 left-2 sm:left-0"
              delay={1.0}
              animation="animate-float-y"
            >
              <div className="flex items-center gap-2">
                <div className="relative h-8 w-8">
                  <svg viewBox="0 0 36 36" className="h-8 w-8 -rotate-90">
                    <circle cx="18" cy="18" r="14" fill="none" stroke="oklch(1 0 0 / 0.1)" strokeWidth="3" />
                    <circle
                      cx="18" cy="18" r="14" fill="none"
                      stroke="oklch(0.85 0.18 155)" strokeWidth="3" strokeLinecap="round"
                      strokeDasharray={`${0.72 * 88} 88`}
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <Target className="h-3 w-3 text-mint" />
                  </div>
                </div>
                <div>
                  <p className="text-[10px] text-muted-foreground">Goal preview</p>
                  <p className="text-[11px] font-semibold">72% · Tokyo trip</p>
                </div>
              </div>
            </FloatingCard>
          </div>
        </div>
      </div>

      <DemoModal open={demoOpen} onClose={() => setDemoOpen(false)} />
    </section>
  );
}

function FloatingCard({
  children, className = "", delay = 0, animation = "animate-float-y",
}: { children: React.ReactNode; className?: string; delay?: number; animation?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 12, scale: 0.95 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{ delay, duration: 0.5 }}
      className={className}
    >
      <div className={`glass-strong rounded-2xl px-3 py-2 shadow-[var(--shadow-card)] ${animation}`}>
        {children}
      </div>
    </motion.div>
  );
}
