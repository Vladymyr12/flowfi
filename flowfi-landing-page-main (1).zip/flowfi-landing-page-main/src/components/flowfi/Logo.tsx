export function Logo({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className="relative h-8 w-8">
        <div className="absolute inset-0 rounded-xl bg-[var(--gradient-primary)] glow-mint" />
        <div className="absolute inset-[3px] rounded-[10px] bg-background flex items-center justify-center">
          <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none">
            <path d="M4 18 Q8 8 12 14 T20 6" stroke="url(#lg)" strokeWidth="2.5" strokeLinecap="round" />
            <defs>
              <linearGradient id="lg" x1="0" x2="24" y1="0" y2="24">
                <stop stopColor="oklch(0.85 0.18 155)" />
                <stop offset="1" stopColor="oklch(0.7 0.23 295)" />
              </linearGradient>
            </defs>
          </svg>
        </div>
      </div>
      <span className="font-display text-lg font-semibold tracking-tight">FlowFi</span>
    </div>
  );
}
