import { motion } from "motion/react";
import { Shield, Zap, Heart, TrendingUp, Lock, Smile } from "lucide-react";
import { SectionHeader } from "./Features";

const items = [
  { icon: TrendingUp, title: "Build wealth, not anxiety", desc: "Watch your money grow with calm clarity.", className: "md:col-span-2 md:row-span-2", big: true },
  { icon: Zap, title: "10× faster decisions", desc: "AI summaries replace hours of spreadsheets." },
  { icon: Shield, title: "Bank-grade security", desc: "256-bit encryption. Biometric lock." },
  { icon: Heart, title: "Built for your habits", desc: "Personalized to how you actually live." },
  { icon: Lock, title: "Your data stays yours", desc: "We never sell. We never snoop." },
  { icon: Smile, title: "Money should feel good", desc: "Delightful interactions on every tap." },
];

export function Bento() {
  return (
    <section className="relative py-20 sm:py-28">
      <div className="mx-auto max-w-6xl px-4">
        <SectionHeader
          tag="Why FlowFi"
          title={<>Designed for the way you <span className="text-gradient">actually live.</span></>}
        />
        <div className="mt-12 grid auto-rows-[160px] gap-3 md:grid-cols-4">
          {items.map((it, i) => (
            <motion.div
              key={it.title}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.05 }}
              className={`group relative overflow-hidden rounded-3xl glass p-5 hover:bg-white/[0.06] ${it.className ?? ""}`}
            >
              {it.big && (
                <div className="pointer-events-none absolute right-0 top-0 h-full w-2/3 bg-[radial-gradient(circle_at_top_right,oklch(0.85_0.18_155/0.25),transparent_60%)]" />
              )}
              <div className="relative flex h-full flex-col">
                <div className="rounded-xl bg-white/5 p-2 w-fit">
                  <it.icon className="h-4 w-4 text-mint" />
                </div>
                <div className="mt-auto">
                  <p className={`font-display font-semibold ${it.big ? "text-2xl sm:text-3xl" : "text-base"}`}>{it.title}</p>
                  <p className="mt-1 text-sm text-muted-foreground">{it.desc}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
