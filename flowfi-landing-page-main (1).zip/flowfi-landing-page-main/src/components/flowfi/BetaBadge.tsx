import { motion } from "motion/react";

export function BetaBadge({
  label = "BETA",
  className = "",
  pulse = true,
}: {
  label?: string;
  className?: string;
  pulse?: boolean;
}) {
  return (
    <span
      className={`relative inline-flex items-center gap-1.5 rounded-full border border-mint/30 bg-mint/10 px-2 py-0.5 text-[10px] font-semibold uppercase tracking-[0.14em] text-mint ${className}`}
    >
      {pulse && (
        <span className="relative flex h-1.5 w-1.5">
          <motion.span
            className="absolute inline-flex h-full w-full rounded-full bg-mint"
            animate={{ opacity: [0.4, 1, 0.4], scale: [1, 1.8, 1] }}
            transition={{ duration: 2, repeat: Infinity }}
          />
          <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-mint" />
        </span>
      )}
      {label}
    </span>
  );
}
