import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ArrowRight, Check, Sparkles, Apple, Play } from "lucide-react";
import { BetaBadge } from "./BetaBadge";

export function Waitlist({ id = "waitlist", compact = false }: { id?: string; compact?: boolean }) {
  const [email, setEmail] = useState("");
  const [state, setState] = useState<"idle" | "loading" | "done">("idle");
  const [focus, setFocus] = useState(false);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.includes("@")) return;
    setState("loading");
    setTimeout(() => setState("done"), 900);
  };

  return (
    <section id={id} className={`relative ${compact ? "py-12" : "py-20 sm:py-28"}`}>
      <div className="mx-auto max-w-3xl px-4">
        <div className="relative overflow-hidden rounded-[36px] glass-strong p-8 sm:p-12 text-center">
          {/* aurora bg */}
          <div className="pointer-events-none absolute inset-0 -z-10">
            <div className="absolute inset-0 bg-[var(--gradient-aurora)] animate-aurora opacity-80" />
            <div className="absolute inset-0 grid-bg opacity-20" />
          </div>

          {/* floating particles */}
          {Array.from({ length: 10 }).map((_, i) => (
            <motion.span
              key={i}
              className="pointer-events-none absolute h-1 w-1 rounded-full bg-mint/70"
              style={{ left: `${(i * 83) % 100}%`, top: `${(i * 41) % 100}%` }}
              animate={{ y: [-8, 8, -8], opacity: [0.2, 0.9, 0.2] }}
              transition={{ duration: 4 + (i % 3), repeat: Infinity, delay: i * 0.2 }}
            />
          ))}

          <div className="flex justify-center">
            <BetaBadge label="Launching Soon" />
          </div>

          <motion.h2
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="mx-auto mt-4 max-w-2xl text-balance font-display text-4xl font-semibold tracking-tight sm:text-5xl"
          >
            Get <span className="text-gradient">early beta access.</span>
          </motion.h2>
          <p className="mx-auto mt-3 max-w-lg text-sm text-muted-foreground sm:text-base">
            FlowFi is still in development. Join the waitlist to be among the first to flow with your money.
          </p>

          {/* Email capture */}
          <form onSubmit={submit} className="relative mx-auto mt-8 max-w-md">
            <AnimatePresence mode="wait">
              {state !== "done" ? (
                <motion.div
                  key="form"
                  exit={{ opacity: 0, y: -6 }}
                  className="relative"
                >
                  {/* glow halo */}
                  <motion.div
                    aria-hidden
                    className="pointer-events-none absolute -inset-2 rounded-full bg-[var(--gradient-primary)] blur-xl"
                    animate={{ opacity: focus ? 0.55 : 0.25 }}
                    transition={{ duration: 0.4 }}
                  />
                  <div className="relative flex items-center gap-1 rounded-full glass-strong p-1.5 pl-5">
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      onFocus={() => setFocus(true)}
                      onBlur={() => setFocus(false)}
                      placeholder="you@email.com"
                      className="flex-1 bg-transparent py-2.5 text-sm outline-none placeholder:text-muted-foreground"
                    />
                    <button
                      type="submit"
                      disabled={state === "loading"}
                      className="group inline-flex items-center gap-1.5 rounded-full bg-[var(--gradient-primary)] px-4 py-2.5 text-sm font-semibold text-background transition-transform hover:scale-[1.03] disabled:opacity-70"
                    >
                      {state === "loading" ? (
                        <motion.span
                          className="h-3.5 w-3.5 rounded-full border-2 border-background border-t-transparent"
                          animate={{ rotate: 360 }}
                          transition={{ duration: 0.7, repeat: Infinity, ease: "linear" }}
                        />
                      ) : (
                        <>
                          Join Waitlist
                          <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
                        </>
                      )}
                    </button>
                  </div>
                </motion.div>
              ) : (
                <motion.div
                  key="done"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="relative flex items-center justify-center gap-3 rounded-full glass-strong px-5 py-3"
                >
                  <motion.div
                    initial={{ scale: 0 }}
                    animate={{ scale: 1 }}
                    transition={{ type: "spring", stiffness: 240, damping: 14 }}
                    className="flex h-7 w-7 items-center justify-center rounded-full bg-[var(--gradient-primary)] glow-mint"
                  >
                    <Check className="h-4 w-4 text-background" strokeWidth={3} />
                  </motion.div>
                  <p className="text-sm">
                    You're on the list. <span className="text-muted-foreground">We'll be in touch.</span>
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </form>

          {/* Coming soon badges */}
          <div className="mt-6 flex flex-wrap items-center justify-center gap-2.5">
            <ComingSoonBadge Icon={Apple} platform="iOS" />
            <ComingSoonBadge Icon={Play} platform="Android" />
          </div>

          <p className="mt-5 inline-flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <Sparkles className="h-3 w-3 text-mint" />
            No spam. One launch email. Unsubscribe anytime.
          </p>
        </div>
      </div>
    </section>
  );
}

function ComingSoonBadge({ Icon, platform }: { Icon: any; platform: string }) {
  return (
    <div className="inline-flex items-center gap-2.5 rounded-xl border border-white/10 bg-white/[0.04] px-3.5 py-2 text-left backdrop-blur">
      <Icon className="h-5 w-5" />
      <div className="leading-tight">
        <p className="text-[9px] uppercase tracking-wider text-muted-foreground">Coming soon on</p>
        <p className="text-xs font-semibold">{platform}</p>
      </div>
    </div>
  );
}
