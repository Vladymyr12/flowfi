import { motion } from "motion/react";
import { Check, Loader2, Sparkles, Rocket, Globe, Coins } from "lucide-react";
import { SectionHeader } from "./Features";
import { BetaBadge } from "./BetaBadge";

const phases = [
  {
    status: "done",
    label: "Shipped",
    icon: Check,
    title: "Core experience",
    items: ["Mobile-first UI", "Expense engine", "Budget visualizer", "Goal tracker"],
  },
  {
    status: "active",
    label: "In progress",
    icon: Loader2,
    title: "Closed beta",
    items: ["Flow AI assistant", "Bank connections (Plaid)", "Subscription radar", "iOS TestFlight"],
  },
  {
    status: "next",
    label: "Next up",
    icon: Sparkles,
    title: "Public launch",
    items: ["Android beta", "Shared goals", "Auto-save rules", "Weekly money reports"],
  },
  {
    status: "later",
    label: "Future vision",
    icon: Rocket,
    title: "FlowFi 2.0",
    items: ["Investment tracking", "Credit-building tools", "AI money coach calls", "Global multi-currency"],
  },
];

export function Roadmap() {
  return (
    <section id="roadmap" className="relative py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-0 -z-10 [mask-image:radial-gradient(ellipse_at_center,black,transparent_70%)]">
        <div className="absolute left-1/2 top-1/3 h-[420px] w-[420px] -translate-x-1/2 rounded-full bg-mint/10 blur-3xl" />
      </div>

      <div className="mx-auto max-w-6xl px-4">
        <SectionHeader
          tag="Roadmap"
          title={<>Built in the open. <span className="text-gradient">Shipped in waves.</span></>}
          subtitle="Here's what's done, what we're building right now, and where we're going next."
        />

        <div className="mt-12 grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {phases.map((p, i) => {
            const isActive = p.status === "active";
            const isDone = p.status === "done";
            return (
              <motion.div
                key={p.title}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.08 }}
                className={`relative overflow-hidden rounded-3xl p-5 ${
                  isActive
                    ? "glass-strong border-mint/30 ring-1 ring-mint/30"
                    : "glass"
                }`}
              >
                {isActive && (
                  <div className="pointer-events-none absolute -inset-1 -z-10 rounded-3xl bg-[var(--gradient-primary)] opacity-25 blur-2xl" />
                )}
                <div className="flex items-center justify-between">
                  <div
                    className={`flex h-9 w-9 items-center justify-center rounded-xl ${
                      isDone
                        ? "bg-mint/20 text-mint"
                        : isActive
                          ? "bg-[var(--gradient-primary)] text-background"
                          : "bg-white/5 text-muted-foreground"
                    }`}
                  >
                    <p.icon className={`h-4 w-4 ${isActive ? "animate-spin-slow" : ""}`} />
                  </div>
                  {isActive && <BetaBadge label="Now" />}
                </div>
                <p className="mt-4 text-[10px] uppercase tracking-[0.18em] text-muted-foreground">{p.label}</p>
                <p className="mt-1 font-display text-lg font-semibold">{p.title}</p>
                <ul className="mt-4 space-y-2">
                  {p.items.map((it) => (
                    <li key={it} className="flex items-start gap-2 text-sm">
                      <span
                        className={`mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full ${
                          isDone ? "bg-mint" : isActive ? "bg-mint animate-pulse" : "bg-white/20"
                        }`}
                      />
                      <span className={isDone ? "text-foreground/85" : "text-foreground/70"}>{it}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            );
          })}
        </div>

        <div className="mt-10 grid gap-3 sm:grid-cols-3">
          <Stat icon={Coins} value="14" label="features in beta" />
          <Stat icon={Loader2} value="6" label="weeks to public launch" spin />
          <Stat icon={Globe} value="Open" label="building in public" />
        </div>
      </div>
    </section>
  );
}

function Stat({ icon: Icon, value, label, spin }: { icon: any; value: string; label: string; spin?: boolean }) {
  return (
    <div className="glass rounded-2xl p-5 text-center">
      <div className="mx-auto flex h-9 w-9 items-center justify-center rounded-xl bg-mint/15">
        <Icon className={`h-4 w-4 text-mint ${spin ? "animate-spin-slow" : ""}`} />
      </div>
      <p className="mt-3 font-display text-2xl font-semibold tracking-tight">{value}</p>
      <p className="text-xs text-muted-foreground">{label}</p>
    </div>
  );
}
