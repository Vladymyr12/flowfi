import { motion } from "motion/react";
import { Heart, MessageCircle } from "lucide-react";
import { SectionHeader } from "./Features";

type Comment = {
  name: string;
  handle: string;
  color: string;
  text: string;
  reply?: string;
};

// Early-tester / beta-waitlist style comments — relatable, no fake metrics.
const comments: Comment[] = [
  {
    name: "Maya",
    handle: "@mayacodes",
    color: "from-pink to-violet",
    text: "I literally never realized how much I was spending on subscriptions until I saw the preview 🫠",
  },
  {
    name: "Jordan",
    handle: "@jordan.t",
    color: "from-mint to-cyan",
    text: "Every budgeting app I've tried felt like homework. This one actually looks like something I'd open.",
  },
  {
    name: "Sana",
    handle: "@sanasaves",
    color: "from-cyan to-violet",
    text: "Finally a finance app that doesn't look like my dad's banking software",
    reply: "literally same energy 😭",
  },
  {
    name: "Devon",
    handle: "@devonbuilds",
    color: "from-amber to-pink",
    text: "Signed up for the waitlist. Money stress is so real and the AI thing is actually genius.",
  },
  {
    name: "Zoe",
    handle: "@zoebudgets",
    color: "from-violet to-mint",
    text: "This is going to make finance feel a lot less stressful for a lot of us. Pls launch soon.",
  },
  {
    name: "Aiden",
    handle: "@aidenw",
    color: "from-pink to-amber",
    text: "the demo had me like… are y'all hiring? this UI is unreal",
  },
];

export function Testimonials() {
  return (
    <section id="reviews" className="relative py-20 sm:py-28">
      <div className="mx-auto max-w-6xl px-4">
        <SectionHeader
          tag="Early reactions"
          title={<>From the people <span className="text-gradient">we're building for.</span></>}
          subtitle="Real comments from early testers, waitlist members, and Discord lurkers."
        />

        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {comments.map((c, i) => (
            <motion.div
              key={c.name}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-10%" }}
              transition={{ delay: (i % 3) * 0.08 }}
              className="space-y-2"
            >
              <CommentBubble {...c} />
              {c.reply && <ReplyBubble text={c.reply} />}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CommentBubble({ name, handle, color, text }: Comment) {
  return (
    <div className="glass rounded-2xl p-4">
      <div className="flex items-center gap-2.5">
        <div className={`h-9 w-9 rounded-full bg-gradient-to-br ${color}`} />
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold leading-tight">{name}</p>
          <p className="text-[11px] text-muted-foreground">{handle}</p>
        </div>
      </div>
      <p className="mt-3 text-[14px] leading-relaxed text-foreground/90">{text}</p>
      <div className="mt-3 flex items-center gap-4 text-[11px] text-muted-foreground">
        <span className="inline-flex items-center gap-1">
          <Heart className="h-3 w-3" /> {Math.floor(Math.random() * 80) + 12}
        </span>
        <span className="inline-flex items-center gap-1">
          <MessageCircle className="h-3 w-3" /> reply
        </span>
      </div>
    </div>
  );
}

function ReplyBubble({ text }: { text: string }) {
  return (
    <div className="ml-6 flex justify-end">
      <div className="max-w-[85%] rounded-2xl rounded-br-sm bg-[var(--gradient-primary)] px-3.5 py-2 text-sm text-background">
        {text}
      </div>
    </div>
  );
}
