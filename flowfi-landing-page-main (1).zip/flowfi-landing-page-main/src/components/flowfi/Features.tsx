import { motion } from "motion/react";
import {
  LayoutDashboard, Receipt, Wallet, Target, LineChart,
  Coffee, ShoppingBag, Utensils, Car, Home, Plane,
} from "lucide-react";

export function Features() {
  return (
    <section id="features" className="relative py-20 sm:py-28">
      <div className="mx-auto max-w-6xl px-4">
        <SectionHeader
          tag="Core features"
          title={<>Everything you need to <span className="text-gradient">flow with money.</span></>}
          subtitle="A complete financial OS built around how you actually spend, save, and grow."
        />

        <div className="mt-12 grid gap-4 md:grid-cols-6">
          <FeatureCard
            className="md:col-span-4"
            icon={LayoutDashboard}
            title="Home dashboard"
            desc="Total balance, weekly trends, and AI summaries — all in one calm, clear view."
            preview={<DashboardPreview />}
          />
          <FeatureCard
            className="md:col-span-2"
            icon={Receipt}
            title="Smart expense tracking"
            desc="Auto-categorized transactions with swipeable cards."
            preview={<ExpensesPreview />}
          />
          <FeatureCard
            className="md:col-span-2"
            icon={Wallet}
            title="Budgets that flex"
            desc="Visual budgets with overspend alerts and AI suggestions."
            preview={<BudgetsPreview />}
          />
          <FeatureCard
            className="md:col-span-2"
            icon={Target}
            title="Savings goals"
            desc="Progress rings, milestones, and automated saves."
            preview={<GoalsPreview />}
          />
          <FeatureCard
            className="md:col-span-2"
            icon={LineChart}
            title="Insights & analytics"
            desc="Heatmaps, trends, and your monthly financial score."
            preview={<InsightsPreview />}
          />
        </div>
      </div>
    </section>
  );
}

export function SectionHeader({
  tag, title, subtitle,
}: { tag: string; title: React.ReactNode; subtitle?: string }) {
  return (
    <div className="mx-auto max-w-2xl text-center">
      <span className="inline-block rounded-full glass px-3 py-1 text-xs text-muted-foreground">{tag}</span>
      <h2 className="mt-4 text-balance font-display text-3xl font-semibold tracking-tight sm:text-5xl">{title}</h2>
      {subtitle && <p className="mt-3 text-sm text-muted-foreground sm:text-base">{subtitle}</p>}
    </div>
  );
}

function FeatureCard({
  icon: Icon, title, desc, preview, className = "",
}: { icon: any; title: string; desc: string; preview: React.ReactNode; className?: string }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-10%" }}
      transition={{ duration: 0.6 }}
      className={`group relative overflow-hidden rounded-3xl glass p-5 transition-all duration-500 hover:bg-white/[0.06] ${className}`}
    >
      <div className="pointer-events-none absolute -right-20 -top-20 h-56 w-56 rounded-full bg-mint/10 blur-3xl transition-opacity duration-500 group-hover:opacity-100 opacity-50" />
      <div className="flex items-center gap-2">
        <div className="rounded-xl bg-white/5 p-2">
          <Icon className="h-4 w-4 text-mint" />
        </div>
        <h3 className="font-display text-lg font-semibold">{title}</h3>
      </div>
      <p className="mt-2 text-sm text-muted-foreground">{desc}</p>
      <div className="mt-5">{preview}</div>
    </motion.div>
  );
}

/* --- Previews --- */

function DashboardPreview() {
  const bars = [42, 28, 65, 38, 80, 55, 70, 45, 90, 60, 78, 50];
  return (
    <div className="rounded-2xl border border-white/5 bg-black/30 p-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Net worth</p>
          <p className="font-display text-2xl font-semibold">$24,318.50</p>
        </div>
        <div className="rounded-full bg-mint/15 px-2 py-0.5 text-[10px] font-medium text-mint">+12.4% MTD</div>
      </div>
      <div className="mt-4 flex h-24 items-end gap-1.5">
        {bars.map((h, i) => (
          <motion.div
            key={i}
            initial={{ scaleY: 0 }}
            whileInView={{ scaleY: 1 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.04, duration: 0.6, ease: "easeOut" }}
            style={{ height: `${h}%`, transformOrigin: "bottom" }}
            className={`flex-1 rounded-md ${i === 8 ? "bg-[var(--gradient-primary)]" : "bg-white/10"}`}
          />
        ))}
      </div>
      <div className="mt-2 flex justify-between text-[9px] text-muted-foreground">
        {["J","F","M","A","M","J","J","A","S","O","N","D"].map((m) => <span key={m}>{m}</span>)}
      </div>
    </div>
  );
}

function ExpensesPreview() {
  const items = [
    { i: Coffee, n: "Café Lou", a: 4.5, c: "text-amber" },
    { i: Utensils, n: "Sweetgreen", a: 14.2, c: "text-mint" },
    { i: Car, n: "Uber", a: 22.0, c: "text-cyan" },
  ];
  return (
    <div className="space-y-1.5">
      {items.map((t, i) => (
        <motion.div
          key={t.n}
          initial={{ opacity: 0, x: -10 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ delay: i * 0.1 }}
          className="flex items-center gap-2 rounded-xl bg-white/[0.04] p-2.5"
        >
          <div className="rounded-lg bg-white/5 p-1.5">
            <t.i className={`h-3.5 w-3.5 ${t.c}`} />
          </div>
          <p className="flex-1 text-xs font-medium">{t.n}</p>
          <p className="text-xs font-semibold">-${t.a.toFixed(2)}</p>
        </motion.div>
      ))}
    </div>
  );
}

function BudgetsPreview() {
  const cats = [
    { n: "Food", v: 78, c: "bg-mint" },
    { n: "Travel", v: 45, c: "bg-violet" },
    { n: "Shopping", v: 92, c: "bg-pink" },
  ];
  return (
    <div className="space-y-3">
      {cats.map((c, i) => (
        <div key={c.n}>
          <div className="mb-1 flex justify-between text-[11px]">
            <span className="text-muted-foreground">{c.n}</span>
            <span className="font-medium">{c.v}%</span>
          </div>
          <div className="h-1.5 overflow-hidden rounded-full bg-white/5">
            <motion.div
              initial={{ width: 0 }}
              whileInView={{ width: `${c.v}%` }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1, duration: 0.9, ease: "easeOut" }}
              className={`h-full ${c.c}`}
            />
          </div>
        </div>
      ))}
    </div>
  );
}

function GoalsPreview() {
  return (
    <div className="grid grid-cols-2 gap-2">
      {[
        { n: "Tokyo", icon: Plane, p: 0.72, color: "oklch(0.85 0.18 155)" },
        { n: "Apt", icon: Home, p: 0.34, color: "oklch(0.7 0.23 295)" },
      ].map((g) => (
        <div key={g.n} className="rounded-xl bg-white/[0.04] p-3 text-center">
          <div className="relative mx-auto h-14 w-14">
            <svg viewBox="0 0 36 36" className="h-14 w-14 -rotate-90">
              <circle cx="18" cy="18" r="15" fill="none" stroke="oklch(1 0 0 / 0.08)" strokeWidth="3" />
              <motion.circle
                cx="18" cy="18" r="15" fill="none"
                stroke={g.color} strokeWidth="3" strokeLinecap="round"
                initial={{ strokeDasharray: "0 94" }}
                whileInView={{ strokeDasharray: `${g.p * 94} 94` }}
                viewport={{ once: true }}
                transition={{ duration: 1.2, ease: "easeOut" }}
              />
            </svg>
            <div className="absolute inset-0 flex items-center justify-center">
              <g.icon className="h-4 w-4" />
            </div>
          </div>
          <p className="mt-1 text-[11px] font-medium">{g.n}</p>
          <p className="text-[10px] text-muted-foreground">{Math.round(g.p * 100)}%</p>
        </div>
      ))}
    </div>
  );
}

function InsightsPreview() {
  return (
    <div className="rounded-xl bg-white/[0.04] p-3">
      <div className="grid grid-cols-7 gap-1">
        {Array.from({ length: 28 }).map((_, i) => {
          const intensity = Math.random();
          return (
            <motion.div
              key={i}
              initial={{ opacity: 0, scale: 0.5 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.015 }}
              style={{
                background: `oklch(0.85 0.18 155 / ${0.08 + intensity * 0.7})`,
              }}
              className="aspect-square rounded-[3px]"
            />
          );
        })}
      </div>
      <div className="mt-3 flex items-center justify-between text-[10px] text-muted-foreground">
        <span>Spending heatmap</span>
        <span className="text-mint font-medium">Score: 87</span>
      </div>
    </div>
  );
}
