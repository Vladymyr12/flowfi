import { motion } from "motion/react";
import { Sparkles, Brain, Zap, MessageCircle, Mic } from "lucide-react";
import { SectionHeader } from "./Features";

const messages = [
  { from: "ai", text: "You spent 32% more on coffee this month ☕ Want me to set a $40 weekly cap?" },
  { from: "me", text: "Yes — and remind me on Mondays." },
  { from: "ai", text: "Done. I also noticed Hulu hasn't been opened in 47 days. Cancel? Save $17.99/mo." },
];

const features = [
  { icon: Brain, title: "Predictive spending", desc: "Forecasts your next 30 days before you even swipe." },
  { icon: Zap, title: "Habit detection", desc: "Spots subscription waste, lifestyle creep, and weekend splurges." },
  { icon: Sparkles, title: "Money coach", desc: "Personalized goals tuned to your income, mood, and season." },
];

export function FlowAI() {
  return (
    <section id="ai" className="relative py-20 sm:py-28">
      <div className="pointer-events-none absolute inset-0 -z-10 [mask-image:radial-gradient(ellipse_at_center,black,transparent_70%)]">
        <div className="absolute left-1/2 top-1/2 h-[500px] w-[500px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-violet/20 blur-3xl animate-pulse-glow" />
      </div>

      <div className="mx-auto max-w-6xl px-4">
        <SectionHeader
          tag="Meet Flow AI"
          title={<>Your <span className="text-gradient-violet">money mentor</span>, in your pocket.</>}
          subtitle="Trained on millions of transactions. Tuned to one — yours."
        />

        <div className="mt-12 grid gap-6 md:grid-cols-5 md:items-center">
          {/* Chat mock */}
          <div className="md:col-span-3">
            <div className="relative">
              <div className="absolute -inset-4 -z-10 rounded-[32px] bg-violet/20 blur-2xl" />
              <div className="glass-strong rounded-3xl p-5">
                <div className="flex items-center gap-2 border-b border-white/5 pb-3">
                  <div className="relative">
                    <div className="h-9 w-9 rounded-full bg-[var(--gradient-violet)] glow-violet flex items-center justify-center">
                      <Sparkles className="h-4 w-4" />
                    </div>
                    <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-mint border-2 border-background" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold">Flow AI</p>
                    <p className="text-[11px] text-muted-foreground">Online · learning your habits</p>
                  </div>
                </div>

                <div className="mt-4 space-y-2.5">
                  {messages.map((m, i) => (
                    <motion.div
                      key={i}
                      initial={{ opacity: 0, y: 8 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: 0.2 + i * 0.2 }}
                      className={`flex ${m.from === "me" ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-[80%] rounded-2xl px-3.5 py-2 text-sm ${
                          m.from === "me"
                            ? "bg-[var(--gradient-primary)] text-background"
                            : "bg-white/[0.06] text-foreground"
                        }`}
                      >
                        {m.text}
                      </div>
                    </motion.div>
                  ))}

                  <motion.div
                    initial={{ opacity: 0 }}
                    whileInView={{ opacity: 1 }}
                    viewport={{ once: true }}
                    transition={{ delay: 1.0 }}
                    className="flex items-center gap-1.5 pl-2"
                  >
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-violet" />
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-violet" style={{ animationDelay: "0.15s" }} />
                    <span className="h-1.5 w-1.5 animate-bounce rounded-full bg-violet" style={{ animationDelay: "0.3s" }} />
                  </motion.div>
                </div>

                <div className="mt-4 flex items-center gap-2 rounded-2xl bg-white/[0.04] p-2.5">
                  <MessageCircle className="h-4 w-4 text-muted-foreground" />
                  <span className="flex-1 text-sm text-muted-foreground">Ask Flow AI anything…</span>
                  <button className="flex h-8 w-8 items-center justify-center rounded-full bg-[var(--gradient-violet)]">
                    <Mic className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>
            </div>
          </div>

          <div className="md:col-span-2 space-y-3">
            {features.map((f, i) => (
              <motion.div
                key={f.title}
                initial={{ opacity: 0, x: 10 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="glass rounded-2xl p-4"
              >
                <div className="flex items-start gap-3">
                  <div className="rounded-xl bg-violet/15 p-2">
                    <f.icon className="h-4 w-4 text-violet" />
                  </div>
                  <div>
                    <p className="font-display font-semibold">{f.title}</p>
                    <p className="mt-0.5 text-sm text-muted-foreground">{f.desc}</p>
                  </div>
                </div>
              </motion.div>
            ))}

            <div className="glass rounded-2xl p-4">
              <p className="text-xs text-muted-foreground">Your financial health score</p>
              <div className="mt-2 flex items-baseline gap-2">
                <span className="font-display text-4xl font-semibold text-gradient-violet">87</span>
                <span className="text-xs text-mint">+6 this month</span>
              </div>
              <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/5">
                <motion.div
                  initial={{ width: 0 }}
                  whileInView={{ width: "87%" }}
                  viewport={{ once: true }}
                  transition={{ duration: 1.4, ease: "easeOut" }}
                  className="h-full bg-[var(--gradient-violet)]"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
