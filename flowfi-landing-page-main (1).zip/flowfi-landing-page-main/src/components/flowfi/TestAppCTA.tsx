import { useState } from "react";
import { motion } from "motion/react";
import { PlayCircle, MousePointerClick, Sparkles } from "lucide-react";
import { DemoModal } from "./DemoModal";
import { BetaBadge } from "./BetaBadge";

export function TestAppCTA() {
  const [open, setOpen] = useState(false);
  return (
    <section className="relative py-20 sm:py-24">
      <div className="mx-auto max-w-5xl px-4">
        <div className="relative overflow-hidden rounded-[36px] glass-strong p-8 sm:p-12">
          <div className="pointer-events-none absolute inset-0 -z-10">
            <div className="absolute inset-0 bg-[var(--gradient-aurora)] animate-aurora opacity-70" />
            <div className="absolute inset-0 grid-bg opacity-20" />
          </div>

          <div className="grid items-center gap-8 md:grid-cols-[1.2fr_1fr]">
            <div>
              <BetaBadge label="Interactive Preview" />
              <motion.h2
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="mt-4 text-balance font-display text-3xl font-semibold tracking-tight sm:text-5xl"
              >
                Try the <span className="text-gradient">test app.</span>
              </motion.h2>
              <p className="mt-3 max-w-md text-sm text-muted-foreground sm:text-base">
                Get a feel for how FlowFi works before launch. Swipe through the dashboard, expenses, goals, and Flow AI — right inside your browser.
              </p>

              <div className="mt-6 flex flex-wrap items-center gap-3">
                <button
                  onClick={() => setOpen(true)}
                  className="group inline-flex items-center gap-2 rounded-full bg-[var(--gradient-primary)] px-5 py-3 text-sm font-semibold text-background hover:scale-[1.03] transition-transform glow-mint"
                >
                  <PlayCircle className="h-4 w-4" />
                  See the Test App
                </button>
                <span className="inline-flex items-center gap-1.5 text-xs text-muted-foreground">
                  <MousePointerClick className="h-3.5 w-3.5" /> Fully interactive prototype
                </span>
              </div>

              <ul className="mt-6 grid grid-cols-2 gap-2 text-xs text-muted-foreground sm:max-w-sm">
                {["Dashboard preview", "Expense tracking", "Savings goals", "AI insights"].map((f) => (
                  <li key={f} className="flex items-center gap-1.5">
                    <Sparkles className="h-3 w-3 text-mint" />
                    {f}
                  </li>
                ))}
              </ul>
            </div>

            {/* Mini phone preview that opens demo on click */}
            <button
              onClick={() => setOpen(true)}
              className="group relative mx-auto block w-[200px] cursor-pointer"
              aria-label="Open test app"
            >
              <div className="absolute -inset-6 -z-10 rounded-[48px] bg-[var(--gradient-aurora)] blur-2xl opacity-80 animate-aurora" />
              <motion.div
                whileHover={{ y: -6, rotate: -2 }}
                transition={{ type: "spring", stiffness: 200 }}
                className="rounded-[32px] bg-gradient-to-b from-white/15 to-white/5 p-[3px] shadow-[0_30px_60px_-20px_rgba(0,0,0,0.6)]"
              >
                <div className="rounded-[30px] bg-[#0a0b12] p-2">
                  <div className="mx-auto mb-1 h-4 w-16 rounded-b-xl bg-black/80" />
                  <div className="relative aspect-[9/16] overflow-hidden rounded-[24px] bg-gradient-to-b from-[#11131c] to-[#0a0b12] p-3">
                    <div className="rounded-xl bg-gradient-to-br from-mint/30 to-violet/30 p-[1px]">
                      <div className="rounded-xl bg-[#0e1018] p-2">
                        <p className="text-[8px] text-white/50">Total</p>
                        <p className="font-display text-sm font-semibold">$12,840</p>
                      </div>
                    </div>
                    <div className="mt-2 space-y-1">
                      {[1, 2, 3].map((i) => (
                        <div key={i} className="h-5 rounded-md bg-white/5" />
                      ))}
                    </div>
                    <div className="absolute inset-x-3 bottom-3 flex h-6 items-center justify-around rounded-full bg-black/60">
                      {[1, 2, 3, 4].map((i) => (
                        <div key={i} className={`h-1 w-1 rounded-full ${i === 1 ? "bg-mint" : "bg-white/30"}`} />
                      ))}
                    </div>
                    {/* Play overlay */}
                    <div className="absolute inset-0 flex items-center justify-center bg-black/0 opacity-0 transition-opacity group-hover:bg-black/40 group-hover:opacity-100">
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-[var(--gradient-primary)] glow-mint">
                        <PlayCircle className="h-6 w-6 text-background" />
                      </div>
                    </div>
                  </div>
                </div>
              </motion.div>
            </button>
          </div>
        </div>
      </div>

      <DemoModal open={open} onClose={() => setOpen(false)} />
    </section>
  );
}
