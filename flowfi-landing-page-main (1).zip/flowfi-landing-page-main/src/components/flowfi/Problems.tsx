import { motion } from "motion/react";
import { CreditCard, Repeat, TrendingDown, Brain, Clock, PiggyBank } from "lucide-react";
import { SectionHeader } from "./Features";

const problems = [
  { icon: Repeat, title: "Subscription leaks", desc: "$200 a month vanishes into apps you forgot you signed up for." },
  { icon: CreditCard, title: "Vibes-based spending", desc: "Tap. Tap. Tap. Where did the paycheck even go?" },
  { icon: TrendingDown, title: "No clue what's left", desc: "Checking your balance shouldn't trigger anxiety." },
  { icon: Brain, title: "Budgeting feels boring", desc: "Spreadsheets weren't built for the TikTok generation." },
  { icon: PiggyBank, title: "Saving feels impossible", desc: "Rent, food, fun — there's nothing left to put away." },
  { icon: Clock, title: "Future you is stressed", desc: "You want to invest. You just don't know where to start." },
];

export function Problems() {
  return (
    <section id="problems" className="relative py-20 sm:py-28">
      <div className="mx-auto max-w-6xl px-4">
        <SectionHeader
          tag="Sound familiar?"
          title={<>Money in your 20s is <span className="text-gradient">a whole vibe.</span></>}
          subtitle="We talked to hundreds of Gen Z and millennials. The same struggles came up over and over."
        />

        <div className="mt-12 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {problems.map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-10%" }}
              transition={{ delay: i * 0.05 }}
              className="group relative overflow-hidden rounded-2xl glass p-5 transition-colors hover:bg-white/[0.06]"
            >
              <div className="pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full bg-pink/10 blur-2xl opacity-0 transition-opacity group-hover:opacity-100" />
              <div className="flex items-center gap-2">
                <div className="rounded-xl bg-white/5 p-2">
                  <p.icon className="h-4 w-4 text-pink" />
                </div>
                <h3 className="font-display text-base font-semibold">{p.title}</h3>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">{p.desc}</p>
            </motion.div>
          ))}
        </div>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          className="mx-auto mt-12 max-w-xl text-center text-base text-muted-foreground sm:text-lg"
        >
          That's exactly why we're building <span className="text-foreground font-medium">FlowFi.</span>
        </motion.p>
      </div>
    </section>
  );
}
