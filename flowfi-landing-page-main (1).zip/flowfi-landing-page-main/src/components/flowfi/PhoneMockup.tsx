import { motion } from "motion/react";
import { ArrowUpRight, Coffee, Music, ShoppingBag, Sparkles, TrendingUp } from "lucide-react";

const tx = [
  { icon: Coffee, name: "Blue Bottle Coffee", cat: "Coffee", amt: -6.5, color: "text-amber" },
  { icon: Music, name: "Spotify Premium", cat: "Subscription", amt: -10.99, color: "text-violet" },
  { icon: ShoppingBag, name: "Uniqlo", cat: "Shopping", amt: -48.0, color: "text-pink" },
  { icon: ArrowUpRight, name: "Salary — Acme Co.", cat: "Income", amt: 3200.0, color: "text-mint" },
];

export function PhoneMockup() {
  return (
    <div className="relative mx-auto w-[280px] sm:w-[320px]">
      {/* Glow */}
      <div className="absolute -inset-10 -z-10 rounded-[60px] bg-[var(--gradient-aurora)] blur-3xl opacity-70 animate-aurora" />

      {/* Phone frame */}
      <div className="relative rounded-[44px] bg-gradient-to-b from-white/15 to-white/5 p-[3px] shadow-[0_40px_80px_-20px_rgba(0,0,0,0.6)]">
        <div className="rounded-[42px] bg-[#0a0b12] p-2">
          {/* Notch */}
          <div className="mx-auto mb-1 h-5 w-24 rounded-b-2xl bg-black/80" />
          <div className="relative overflow-hidden rounded-[36px] bg-gradient-to-b from-[#11131c] to-[#0a0b12] aspect-[9/19.5]">
            {/* Status bar */}
            <div className="flex items-center justify-between px-5 pt-3 text-[10px] text-white/70">
              <span>9:41</span>
              <span className="font-mono">FlowFi</span>
              <span>100%</span>
            </div>

            {/* Header */}
            <div className="px-5 pt-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-[11px] text-white/50">Hello, Maya</p>
                  <p className="text-[13px] font-medium">Welcome back 👋</p>
                </div>
                <div className="h-8 w-8 rounded-full bg-gradient-to-br from-pink/60 to-violet/60" />
              </div>
            </div>

            {/* Balance card */}
            <div className="mx-5 mt-4 rounded-2xl bg-gradient-to-br from-mint/30 via-cyan/10 to-violet/30 p-[1px]">
              <div className="rounded-2xl bg-[#0e1018] p-4">
                <p className="text-[10px] uppercase tracking-wider text-white/50">Total balance</p>
                <div className="mt-1 flex items-baseline gap-2">
                  <span className="font-display text-2xl font-semibold tracking-tight">$12,840</span>
                  <span className="text-[11px] text-mint">+8.4%</span>
                </div>
                <MiniChart />
              </div>
            </div>

            {/* AI insight */}
            <motion.div
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="mx-5 mt-3 flex items-start gap-2 rounded-2xl border border-violet/30 bg-violet/10 p-3"
            >
              <div className="rounded-lg bg-violet/30 p-1.5">
                <Sparkles className="h-3 w-3 text-white" />
              </div>
              <p className="text-[11px] leading-snug text-white/85">
                <span className="font-medium text-violet">Flow AI</span> · You'll save $214 this month if you skip 3 coffee runs.
              </p>
            </motion.div>

            {/* Transactions */}
            <div className="px-5 pt-4">
              <div className="mb-2 flex items-center justify-between">
                <p className="text-[11px] font-medium text-white/70">Recent activity</p>
                <p className="text-[10px] text-white/40">Today</p>
              </div>
              <div className="space-y-1.5">
                {tx.map((t, i) => (
                  <motion.div
                    key={t.name}
                    initial={{ opacity: 0, x: 10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.6 + i * 0.08 }}
                    className="flex items-center gap-2 rounded-xl bg-white/[0.04] p-2"
                  >
                    <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-white/5">
                      <t.icon className={`h-3.5 w-3.5 ${t.color}`} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[11px] font-medium">{t.name}</p>
                      <p className="text-[9px] text-white/40">{t.cat}</p>
                    </div>
                    <p className={`text-[11px] font-semibold ${t.amt > 0 ? "text-mint" : "text-white/85"}`}>
                      {t.amt > 0 ? "+" : ""}${Math.abs(t.amt).toFixed(2)}
                    </p>
                  </motion.div>
                ))}
              </div>
            </div>

            {/* Bottom nav */}
            <div className="absolute inset-x-3 bottom-3 flex items-center justify-between rounded-2xl bg-black/40 px-4 py-2.5 backdrop-blur">
              <NavDot active />
              <NavDot />
              <div className="-mt-6 flex h-10 w-10 items-center justify-center rounded-full bg-[var(--gradient-primary)] glow-mint">
                <TrendingUp className="h-4 w-4 text-background" />
              </div>
              <NavDot />
              <NavDot />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function NavDot({ active = false }: { active?: boolean }) {
  return <div className={`h-1.5 w-1.5 rounded-full ${active ? "bg-mint" : "bg-white/20"}`} />;
}

function MiniChart() {
  const points = [20, 14, 22, 16, 26, 18, 30, 22, 34, 28, 40, 32];
  const max = Math.max(...points);
  const path = points
    .map((p, i) => `${(i / (points.length - 1)) * 100},${40 - (p / max) * 36}`)
    .join(" L");
  return (
    <svg viewBox="0 0 100 40" className="mt-3 h-12 w-full" preserveAspectRatio="none">
      <defs>
        <linearGradient id="ph" x1="0" x2="0" y1="0" y2="1">
          <stop stopColor="oklch(0.85 0.18 155)" stopOpacity="0.5" />
          <stop offset="1" stopColor="oklch(0.85 0.18 155)" stopOpacity="0" />
        </linearGradient>
      </defs>
      <motion.path
        d={`M${path}`}
        fill="none"
        stroke="oklch(0.85 0.18 155)"
        strokeWidth="1.5"
        strokeLinecap="round"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 1.4, ease: "easeOut" }}
      />
      <path d={`M0,40 L${path} L100,40 Z`} fill="url(#ph)" />
    </svg>
  );
}
