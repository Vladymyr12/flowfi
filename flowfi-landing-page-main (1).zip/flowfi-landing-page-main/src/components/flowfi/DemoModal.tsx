import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { X, Sparkles, TrendingUp, Wallet, Target, ChevronRight, Coffee, Music, ShoppingBag, Utensils, Plane, Home } from "lucide-react";
import { BetaBadge } from "./BetaBadge";

type Screen = "home" | "expenses" | "goals" | "insights";

export function DemoModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [screen, setScreen] = useState<Screen>("home");

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] flex items-center justify-center p-4"
        >
          <motion.div
            className="absolute inset-0 bg-background/80 backdrop-blur-md"
            onClick={onClose}
          />

          <motion.div
            initial={{ y: 30, scale: 0.96, opacity: 0 }}
            animate={{ y: 0, scale: 1, opacity: 1 }}
            exit={{ y: 20, scale: 0.96, opacity: 0 }}
            transition={{ type: "spring", stiffness: 220, damping: 24 }}
            className="relative w-full max-w-md"
          >
            <div className="absolute -inset-4 -z-10 rounded-[40px] bg-[var(--gradient-aurora)] blur-3xl opacity-80 animate-aurora" />

            <div className="relative rounded-[36px] glass-strong p-4">
              <div className="mb-3 flex items-center justify-between px-1">
                <div className="flex items-center gap-2">
                  <BetaBadge label="Interactive demo" />
                </div>
                <button
                  onClick={onClose}
                  className="rounded-full glass p-2 hover:bg-white/[0.08]"
                  aria-label="Close demo"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              {/* Phone-style screen */}
              <div className="relative overflow-hidden rounded-[28px] bg-[#0a0b12] aspect-[9/16]">
                <div className="flex items-center justify-between px-5 pt-3 text-[10px] text-white/70">
                  <span>9:41</span>
                  <span className="font-mono">FlowFi · beta</span>
                  <span>100%</span>
                </div>

                <div className="relative h-[calc(100%-58px)] overflow-y-auto px-4 pt-3 scrollbar-hidden">
                  <AnimatePresence mode="wait">
                    {screen === "home" && <HomeScreen key="home" />}
                    {screen === "expenses" && <ExpensesScreen key="expenses" />}
                    {screen === "goals" && <GoalsScreen key="goals" />}
                    {screen === "insights" && <InsightsScreen key="insights" />}
                  </AnimatePresence>
                </div>

                {/* Bottom tab nav */}
                <div className="absolute inset-x-3 bottom-3 grid grid-cols-4 gap-1 rounded-2xl bg-black/60 p-1.5 backdrop-blur">
                  <TabBtn active={screen === "home"} onClick={() => setScreen("home")} icon={TrendingUp} label="Home" />
                  <TabBtn active={screen === "expenses"} onClick={() => setScreen("expenses")} icon={Wallet} label="Spend" />
                  <TabBtn active={screen === "goals"} onClick={() => setScreen("goals")} icon={Target} label="Goals" />
                  <TabBtn active={screen === "insights"} onClick={() => setScreen("insights")} icon={Sparkles} label="AI" />
                </div>
              </div>

              <p className="mt-3 text-center text-[11px] text-muted-foreground">
                Tap the tabs to explore. This is a UI prototype — full app launches with beta access.
              </p>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function TabBtn({
  active, onClick, icon: Icon, label,
}: { active: boolean; onClick: () => void; icon: any; label: string }) {
  return (
    <button
      onClick={onClick}
      className={`flex flex-col items-center gap-0.5 rounded-xl py-1.5 transition-all ${
        active ? "bg-[var(--gradient-primary)] text-background" : "text-white/60 hover:text-white"
      }`}
    >
      <Icon className="h-3.5 w-3.5" />
      <span className="text-[9px] font-medium">{label}</span>
    </button>
  );
}

const fade = {
  initial: { opacity: 0, y: 8 },
  animate: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -8 },
  transition: { duration: 0.25 },
};

function HomeScreen() {
  const tx = [
    { icon: Coffee, name: "Blue Bottle", cat: "Coffee", amt: -6.5 },
    { icon: Music, name: "Spotify", cat: "Subscription", amt: -10.99 },
    { icon: ShoppingBag, name: "Uniqlo", cat: "Shopping", amt: -48.0 },
  ];
  return (
    <motion.div {...fade}>
      <div>
        <p className="text-[11px] text-white/50">Hello, Maya</p>
        <p className="text-[13px] font-medium">Welcome back 👋</p>
      </div>
      <div className="mt-3 rounded-2xl bg-gradient-to-br from-mint/30 via-cyan/10 to-violet/30 p-[1px]">
        <div className="rounded-2xl bg-[#0e1018] p-4">
          <p className="text-[10px] uppercase tracking-wider text-white/50">Total balance</p>
          <p className="font-display text-2xl font-semibold">$12,840.20</p>
          <div className="mt-3 flex h-10 items-end gap-1">
            {[24, 32, 22, 40, 30, 48, 36, 52, 44, 60, 50, 68].map((h, i) => (
              <motion.div
                key={i}
                initial={{ scaleY: 0 }}
                animate={{ scaleY: 1 }}
                transition={{ delay: i * 0.04 }}
                style={{ height: `${h}%`, transformOrigin: "bottom" }}
                className={`flex-1 rounded-sm ${i > 8 ? "bg-mint" : "bg-white/15"}`}
              />
            ))}
          </div>
        </div>
      </div>
      <div className="mt-3 rounded-2xl border border-violet/30 bg-violet/10 p-3">
        <p className="text-[11px] leading-snug text-white/85">
          <Sparkles className="mr-1 inline h-3 w-3 text-violet" />
          <span className="font-medium text-violet">Flow AI</span> · Skip 3 coffee runs to save $214 this month.
        </p>
      </div>
      <div className="mt-3 mb-20">
        <p className="mb-2 text-[11px] font-medium text-white/70">Recent activity</p>
        <div className="space-y-1.5">
          {tx.map((t, i) => (
            <motion.div
              key={t.name}
              initial={{ opacity: 0, x: 8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.2 + i * 0.08 }}
              className="flex items-center gap-2 rounded-xl bg-white/[0.04] p-2"
            >
              <div className="rounded-lg bg-white/5 p-1.5">
                <t.icon className="h-3.5 w-3.5 text-mint" />
              </div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-[11px] font-medium">{t.name}</p>
                <p className="text-[9px] text-white/40">{t.cat}</p>
              </div>
              <p className="text-[11px] font-semibold">${Math.abs(t.amt).toFixed(2)}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </motion.div>
  );
}

function ExpensesScreen() {
  const cats = [
    { n: "Food", v: 78, c: "bg-mint", amt: 312 },
    { n: "Travel", v: 45, c: "bg-violet", amt: 180 },
    { n: "Shopping", v: 92, c: "bg-pink", amt: 368 },
    { n: "Coffee", v: 64, c: "bg-amber", amt: 96 },
  ];
  return (
    <motion.div {...fade}>
      <p className="font-display text-lg font-semibold">Spending</p>
      <p className="text-[11px] text-white/50">November · $956 of $1,200</p>
      <div className="mt-4 space-y-3">
        {cats.map((c, i) => (
          <div key={c.n}>
            <div className="mb-1 flex justify-between text-[11px]">
              <span className="text-white/70">{c.n}</span>
              <span className="font-medium">${c.amt}</span>
            </div>
            <div className="h-1.5 overflow-hidden rounded-full bg-white/5">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: `${c.v}%` }}
                transition={{ delay: i * 0.08, duration: 0.8 }}
                className={`h-full ${c.c}`}
              />
            </div>
          </div>
        ))}
      </div>
      <div className="mt-5 mb-20 rounded-2xl bg-white/[0.04] p-3">
        <p className="text-[10px] uppercase tracking-wider text-white/50">Subscriptions detected</p>
        {[
          { n: "Spotify", a: 10.99 },
          { n: "Hulu", a: 17.99 },
          { n: "iCloud+", a: 2.99 },
        ].map((s) => (
          <div key={s.n} className="mt-2 flex items-center justify-between text-[11px]">
            <span>{s.n}</span>
            <span className="font-medium">${s.a}/mo</span>
          </div>
        ))}
      </div>
    </motion.div>
  );
}

function GoalsScreen() {
  const goals = [
    { n: "Tokyo trip", icon: Plane, p: 0.72, color: "oklch(0.85 0.18 155)", saved: 2160, total: 3000 },
    { n: "Move out", icon: Home, p: 0.34, color: "oklch(0.7 0.23 295)", saved: 1700, total: 5000 },
  ];
  return (
    <motion.div {...fade}>
      <p className="font-display text-lg font-semibold">Goals</p>
      <p className="text-[11px] text-white/50">2 active · auto-saving weekly</p>
      <div className="mt-4 mb-20 space-y-3">
        {goals.map((g, i) => (
          <motion.div
            key={g.n}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            className="rounded-2xl bg-white/[0.04] p-4"
          >
            <div className="flex items-center gap-3">
              <div className="relative h-14 w-14">
                <svg viewBox="0 0 36 36" className="h-14 w-14 -rotate-90">
                  <circle cx="18" cy="18" r="15" fill="none" stroke="oklch(1 0 0 / 0.08)" strokeWidth="3" />
                  <motion.circle
                    cx="18" cy="18" r="15" fill="none"
                    stroke={g.color} strokeWidth="3" strokeLinecap="round"
                    initial={{ strokeDasharray: "0 94" }}
                    animate={{ strokeDasharray: `${g.p * 94} 94` }}
                    transition={{ duration: 1, ease: "easeOut", delay: i * 0.15 }}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <g.icon className="h-4 w-4" />
                </div>
              </div>
              <div className="flex-1">
                <p className="text-sm font-medium">{g.n}</p>
                <p className="text-[11px] text-white/50">${g.saved.toLocaleString()} of ${g.total.toLocaleString()}</p>
                <p className="mt-1 text-[10px] text-mint">{Math.round(g.p * 100)}% complete</p>
              </div>
              <ChevronRight className="h-4 w-4 text-white/40" />
            </div>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
}

function InsightsScreen() {
  return (
    <motion.div {...fade}>
      <p className="font-display text-lg font-semibold">Flow AI</p>
      <p className="text-[11px] text-white/50">Insights for this week</p>

      <div className="mt-4 space-y-2">
        {[
          { t: "You spent 32% more on coffee ☕", s: "Suggest a $40 weekly cap?" },
          { t: "Hulu hasn't opened in 47 days", s: "Cancel → save $17.99/mo." },
          { t: "Grocery spend down 18% 🎉", s: "You're on track for a record month." },
        ].map((m, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: i * 0.15 }}
            className="rounded-2xl border border-violet/20 bg-violet/10 p-3"
          >
            <p className="text-[12px] font-medium text-white/90">{m.t}</p>
            <p className="text-[11px] text-white/60">{m.s}</p>
          </motion.div>
        ))}
      </div>

      <div className="mt-5 mb-20 rounded-2xl bg-white/[0.04] p-4">
        <p className="text-[11px] text-white/50">Financial health</p>
        <p className="font-display text-3xl font-semibold text-gradient-violet">87</p>
        <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-white/5">
          <motion.div
            initial={{ width: 0 }}
            animate={{ width: "87%" }}
            transition={{ duration: 1.2 }}
            className="h-full bg-[var(--gradient-violet)]"
          />
        </div>
      </div>
    </motion.div>
  );
}
